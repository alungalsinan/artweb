"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { FixtureCard } from "@/components/sports/fixture-card"
import { LiveScoreTracker } from "@/components/sports/live-score-tracker"
import { Search, Filter } from "lucide-react"

// Mock data for fixtures
const mockFixtures = [
  {
    id: "1",
    sport: "Football",
    category: "Thaniya",
    team1: "Fulful",
    team2: "Kafur",
    date: "2024-01-15",
    time: "10:00 AM",
    venue: "Main Ground",
    status: "upcoming" as const,
  },
  {
    id: "2",
    sport: "Basketball",
    category: "Aliya",
    team1: "Zanjabeel",
    team2: "Fulful",
    date: "2024-01-15",
    time: "2:00 PM",
    venue: "Indoor Court",
    status: "ongoing" as const,
    score: { team1: 45, team2: 38 },
  },
  {
    id: "3",
    sport: "Cricket",
    category: "Kulliyya",
    team1: "Kafur",
    team2: "Zanjabeel",
    date: "2024-01-14",
    time: "9:00 AM",
    venue: "Cricket Ground",
    status: "completed" as const,
    score: { team1: 156, team2: 142 },
  },
]

const mockLiveMatches = [
  {
    id: "2",
    sport: "Basketball",
    team1: "Zanjabeel",
    team2: "Fulful",
    score: { team1: 45, team2: 38 },
    time: "28:45",
    status: "ongoing" as const,
  },
]

export default function FixturesPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedSport, setSelectedSport] = useState("all")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [selectedStatus, setSelectedStatus] = useState("all")

  const filteredFixtures = mockFixtures.filter((fixture) => {
    const matchesSearch =
      fixture.sport.toLowerCase().includes(searchTerm.toLowerCase()) ||
      fixture.team1.toLowerCase().includes(searchTerm.toLowerCase()) ||
      fixture.team2.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesSport = selectedSport === "all" || fixture.sport === selectedSport
    const matchesCategory = selectedCategory === "all" || fixture.category === selectedCategory
    const matchesStatus = selectedStatus === "all" || fixture.status === selectedStatus

    return matchesSearch && matchesSport && matchesCategory && matchesStatus
  })

  const upcomingFixtures = filteredFixtures.filter((f) => f.status === "upcoming")
  const ongoingFixtures = filteredFixtures.filter((f) => f.status === "ongoing")
  const completedFixtures = filteredFixtures.filter((f) => f.status === "completed")

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Sports Fixtures</h1>
        <p className="text-gray-600">View match schedules, live scores, and results</p>
      </div>

      {/* Live Matches Section */}
      {mockLiveMatches.length > 0 && (
        <div className="mb-8">
          <h2 className="text-2xl font-semibold mb-4 flex items-center gap-2">
            <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
            Live Matches
          </h2>
          <div className="grid gap-6">
            {mockLiveMatches.map((match) => (
              <LiveScoreTracker key={match.id} match={match} />
            ))}
          </div>
        </div>
      )}

      {/* Filters */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Filters
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search fixtures..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={selectedSport} onValueChange={setSelectedSport}>
              <SelectTrigger>
                <SelectValue placeholder="Select Sport" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Sports</SelectItem>
                <SelectItem value="Football">Football</SelectItem>
                <SelectItem value="Basketball">Basketball</SelectItem>
                <SelectItem value="Cricket">Cricket</SelectItem>
                <SelectItem value="Volleyball">Volleyball</SelectItem>
              </SelectContent>
            </Select>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger>
                <SelectValue placeholder="Select Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="Bidaya">Bidaya</SelectItem>
                <SelectItem value="Uoola">Uoola</SelectItem>
                <SelectItem value="Thaniya">Thaniya</SelectItem>
                <SelectItem value="Thanawiyya">Thanawiyya</SelectItem>
                <SelectItem value="Aliya">Aliya</SelectItem>
                <SelectItem value="Kulliyya">Kulliyya</SelectItem>
              </SelectContent>
            </Select>
            <Select value={selectedStatus} onValueChange={setSelectedStatus}>
              <SelectTrigger>
                <SelectValue placeholder="Select Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="upcoming">Upcoming</SelectItem>
                <SelectItem value="ongoing">Ongoing</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Fixtures Tabs */}
      <Tabs defaultValue="all" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="all">All Fixtures</TabsTrigger>
          <TabsTrigger value="upcoming">Upcoming ({upcomingFixtures.length})</TabsTrigger>
          <TabsTrigger value="ongoing">Ongoing ({ongoingFixtures.length})</TabsTrigger>
          <TabsTrigger value="completed">Completed ({completedFixtures.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredFixtures.map((fixture) => (
              <FixtureCard key={fixture.id} fixture={fixture} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="upcoming" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {upcomingFixtures.map((fixture) => (
              <FixtureCard key={fixture.id} fixture={fixture} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="ongoing" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {ongoingFixtures.map((fixture) => (
              <FixtureCard key={fixture.id} fixture={fixture} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="completed" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {completedFixtures.map((fixture) => (
              <FixtureCard key={fixture.id} fixture={fixture} />
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
