"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Calendar, Clock, MapPin, Users } from "lucide-react"

interface Fixture {
  id: string
  sport: string
  category: string
  team1: string
  team2: string
  date: string
  time: string
  venue: string
  status: "upcoming" | "ongoing" | "completed"
  score?: {
    team1: number
    team2: number
  }
}

interface FixtureCardProps {
  fixture: Fixture
  onViewDetails?: (fixture: Fixture) => void
}

export function FixtureCard({ fixture, onViewDetails }: FixtureCardProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "upcoming":
        return "bg-blue-100 text-blue-800"
      case "ongoing":
        return "bg-green-100 text-green-800"
      case "completed":
        return "bg-gray-100 text-gray-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">{fixture.sport}</CardTitle>
          <Badge className={getStatusColor(fixture.status)}>
            {fixture.status.charAt(0).toUpperCase() + fixture.status.slice(1)}
          </Badge>
        </div>
        <p className="text-sm text-muted-foreground">{fixture.category}</p>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Teams */}
        <div className="flex items-center justify-between">
          <div className="text-center flex-1">
            <p className="font-medium">{fixture.team1}</p>
            {fixture.score && <p className="text-2xl font-bold text-primary">{fixture.score.team1}</p>}
          </div>
          <div className="px-4">
            <Users className="h-6 w-6 text-muted-foreground" />
          </div>
          <div className="text-center flex-1">
            <p className="font-medium">{fixture.team2}</p>
            {fixture.score && <p className="text-2xl font-bold text-primary">{fixture.score.team2}</p>}
          </div>
        </div>

        {/* Match Details */}
        <div className="space-y-2 text-sm text-muted-foreground">
          <div className="flex items-center gap-2">
            <Calendar className="h-4 w-4" />
            <span>{fixture.date}</span>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="h-4 w-4" />
            <span>{fixture.time}</span>
          </div>
          <div className="flex items-center gap-2">
            <MapPin className="h-4 w-4" />
            <span>{fixture.venue}</span>
          </div>
        </div>

        {onViewDetails && (
          <Button variant="outline" className="w-full bg-transparent" onClick={() => onViewDetails(fixture)}>
            View Details
          </Button>
        )}
      </CardContent>
    </Card>
  )
}
